Svetlozar.NET Contacts Importer - Gmail Only Version (FREE)

Please edit the files in /example as needed. You need to add your own logic for handling the imported contacts (this applies to the complete version too), no mailing functionality is provided. Use SwiftMailer or PHPMailer if you need to send out email from your application.